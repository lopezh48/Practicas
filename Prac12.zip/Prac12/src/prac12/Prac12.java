/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac12;

/**
 *
 * @author ascr4
 */
public class Prac12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Mat[][]=new int [3][5];
        //For anidados
        for (int i = 0; i < Mat.length; i++) {
            for (int j = 0; j < Mat[i].length; j++) {
                Mat[i][j]=(int)(Math.random()*100)+1;
            }
        }
        //Imprimir la matriz
        for (int i = 0; i < Mat.length; i++) {
            for (int j = 0; j < Mat[i].length; j++) {
                System.out.print("["+Mat[i][j]+"]");
            }
            System.out.println("");
        }
    }
    
}
