/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac9;

/**
 *
 * @author ascr4
 */
public class Prac9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Prue [] Arre=new Prue[5];
        System.out.println(Arre);
        for (int i = 0; i < Arre.length; i++) {
            Arre[i]=new Prue();  //Creando objeto de tipo Prue
            System.out.println(Arre[i]);
        }
    }
    
}
class Prue{}