/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac15;

/**
 *
 * @author ascr4
 */
public class Prac15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Num=10;
        System.out.println("Valor = "+Num);
        incre(Num);
        System.out.println("Valor = "+Num);
        //--
        Prueba obj=new Prueba();
        obj.Val=10;
        System.out.println("Valor = "+obj.Val);
        increObj(obj);
        System.out.println("Valor = "+obj.Val);
    }
    public static void incre (int Val){
        Val++;
        System.out.println("Valor = "+Val);
    }
    public static void increObj(Prueba obj){
        obj.Val++;
    }
    
}
class Prueba{
    int Val;
}
