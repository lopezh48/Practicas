/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac8;

/**
 *
 * @author ascr4
 */
public class Prac8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Dat[];
        int Copia[];
        Dat=new int[10];
        Copia=new int[10];
        for (int i = 0; i < Dat.length; i++){
            Dat[i]=(int)(Math.random()*100)+1;
        }
        //Copia = Dat // Aqui copiamos direcciones
        //Elemento por elemento
        for (int i = 0; i < Dat.length; i++){
            Copia[i]=Dat[i];
        }
        Imp(Dat);
        Imp(Copia);
        System.out.println(Copia);
        System.out.println(Dat);
    }
    public static void Imp(int[] args){
        for (int i = 0; i < args.length; i++) {
            System.out.println("["+args[i]+"]");
        }
    }
    
}
