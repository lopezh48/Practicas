/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac13;

/**
 *
 * @author ascr4
 */
public class Prac13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Mat[][][][][]=new int[5][3][8][10][11];
        for (int i = 0; i < Mat.length; i++) {
            for (int j = 0; j < Mat[i].length; j++) {
                for (int k = 0; k < Mat[i][j].length; k++) {
                    for (int l = 0; l < Mat[i][j][k].length; l++) {
                        for (int m = 0; m < Mat[i][j][k][l].length; m++) {
                            Mat[i][j][k][l][m]=(int)(Math.random()*100)+1;
                        }
                    }
                }
            }
        }
        for (int i = 0; i < Mat.length; i++) {
            for (int j = 0; j < Mat[i].length; j++) {
                for (int k = 0; k < Mat[i][j].length; k++) {
                    for (int l = 0; l < Mat[i][j][k].length; l++) {
                        for (int m = 0; m < Mat[i][j][k][l].length; m++) {
                            System.out.println("["+Mat[i][j][k][l][m]+"]");
                        }
                        System.out.println("");
                    }
                }
            }
        }
    }
    
}
