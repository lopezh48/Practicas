/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac11;

/**
 *
 * @author ascr4
 */
public class Prac11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Arreglo de 2 dimensiones --> Matriz
        int Dat[][]=new int [3][4];
        System.out.println("Direccion del arreglo "+Dat);
        System.out.println("Tamaño del arreglo "+Dat.length); //Direccion del arreglo
        
        System.out.println("Direccion del arreglo Dat[0] "+Dat[0]);
        System.out.println("Tamaño del arreglo Dat[0] "+Dat[0].length); //Direccion
        
        System.out.println("Valor de la posicion[0][0] "+Dat[0][0]); //Datos
    }
    
}
