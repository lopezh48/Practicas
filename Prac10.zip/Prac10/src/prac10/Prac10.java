/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac10;

import java.util.Scanner;

/**
 *
 * @author ascr4
 */
public class Prac10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Personas[] Nom=new Personas[5];
        Scanner Cap=new Scanner(System.in);
        for (int i = 0; i < Nom.length; i++) {
            Nom[i]=new Personas();
            System.out.println("Introduce tu nombre: ");
            Nom[i].Nombre= Cap.nextLine();
        }
        Imp(Nom);
        //Copia del arreglo
        Personas[] Copia=new Personas[Nom.length];
        for (int i = 0; i < Nom.length; i++) {
            Copia[i]=new Personas();
            Copia[i].Nombre=Nom[i].Nombre;
        }
    }
    public static void Imp(Personas []args){
        for (int i = 0; i < args.length; i++) {
            System.out.println("Nombre: "+args[i].Nombre);
        }
    }
    
}
class Personas{
    String Nombre;
}
