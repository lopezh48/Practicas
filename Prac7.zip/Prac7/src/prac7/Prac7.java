/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac7;

/**
 *
 * @author ascr4
 */
public class Prac7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Copia[];
        int Dat[];
        Dat=new int[10];
        Copia=new int[10];
        for (int i = 0; i < Dat.length; i++) {
            Dat[i]=(int)(Math.random()*100)+1;
        }
        System.out.println("Datos originales");
        for (int i = 0; i < Dat.length; i++) {
            System.out.println("["+Dat[i]+"]");
        }
        System.out.println("Datos copiados");
        for (int i = 0; i < Dat.length; i++) {
            Dat[i]=(int)(Math.random()+100)+1;
        }
    }
    
}
