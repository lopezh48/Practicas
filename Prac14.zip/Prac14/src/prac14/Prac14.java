/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac14;

/**
 *
 * @author ascr4
 */
public class Prac14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Mat[][]=new int [2][3];
        int Mat2[][];
        Mat2=new int [3][];
        Mat2[0]=new int [10];
        Mat2[1]=new int [100];
        Mat2[2]=new int [24];
        for (int i = 0; i < Mat2.length; i++) {
            for (int j = 0; j < Mat2[i].length; j++) {
                Mat2[i][j]=(int)(Math.random()*100)+1;
            }
        }
        for (int i = 0; i < Mat2.length; i++) {
            for (int j = 0; j < Mat2[i].length; j++) {
                System.out.print("["+Mat2[i][j]+"]");
            }
            System.out.println("");
        }
    }
    
}
